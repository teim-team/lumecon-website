# Lumecon Map — Reservation Geographies (self-contained rebuild brief)

This brief is written for a Claude Code session that **does NOT have access to
the lumecon-website repo**. It describes how the interactive impact-study map
works, with the reservation (tribal-land) geography path in full detail, plus
the exact data shapes, projection math, and the runtime DOM contract.

> The actual source files are shipped alongside this brief in the same archive
> (see "Files in this archive" below). The reservation polygon geometry is a
> 271 KB generated artifact that cannot be inlined into a doc — it lives in
> `src/data/tribalLands.generated.js` in the archive. Keep that file; it is the
> one piece that cannot be regenerated without the original Census shapefiles.

---

## 1. What the map is

An interactive US map. Hovering a region inspects it; clicking/tapping runs a
live economic-impact study (animated source dot + spillover flow lines + a
figures table). Three switchable layers:

- **States** — `us-atlas` states (albers-10m).
- **Counties** — `us-atlas` counties (lazy border mesh + centroids).
- **Tribal lands (reservations)** — Census TIGER/Line 2018 **AIANNH** polygons
  (American Indian / Alaska Native / Native Hawaiian areas), 491 features.

Page lives at `/map`. Geography source label in the footer:
`Geography: Census TIGER/Line. Multipliers illustrative.`

---

## 2. Stack & exact dependencies

- **Astro 6** (`type: module`, Node >= 22). Pages are `.astro`; the map runtime
  is a TS module bundled by Astro/Vite.
- Map/geo libraries (versions from `package.json`):
  - `d3-geo@^3.1.1` — `geoPath`, `geoAlbersUsa`, `geoContains`
  - `topojson-client@^3.1.0` — `mesh`, `feature`
  - `us-atlas@^3.0.1` — ships `states-albers-10m.json` and
    `counties-albers-10m.json` (TopoJSON, pre-projected)
  - `fuse.js@7.4.2` — fuzzy search in the workspace search box
- Build: `npm run dev` (astro dev) / `npm run build` (astro check && astro build)
  / `npm run preview`.

---

## 3. File map (all included in the archive)

| File | Role |
|------|------|
| `src/pages/map.astro` | The `/map` page: framing header, `<MapWorkspace/>`, inputs/why sections, CTA. |
| `src/components/MapWorkspace.astro` | **SSR brain.** Builds the SVG, state/county/tribal data, search index, tribal lookup. Emits inline JSON `<script>` blocks the runtime reads. |
| `src/scripts/hero.ts` | **Client runtime** (1035 lines): hover, click→runStudy, layer switching, lazy-load AIANNH, flow lines, search. |
| `src/styles/hero.css` | All map/workspace styling (1747 lines). |
| `src/styles/map-page.css` | `/map` page chrome (header, inputs, CTA). |
| `src/data/tribalLands.generated.js` | **Generated** AIANNH polygons (`CENSUS_TRIBAL_LANDS`, 491 features, 271 KB). Do not hand-edit. |
| `src/data/tribalLookup.ts` | `TRIBAL_SCENE_KEYS` (name→slug) + `MANUAL_TRIBES` (hand-anchored centroids absent from Census). |
| `src/data/countyMatch.ts` | `findContainingCounty(cx,cy)` — inverts the albers point and runs `geoContains` so a reservation can light up its containing county. |
| `src/pages/data/aiannh.json.ts` | Prerendered endpoint at `/data/aiannh.json` serving the polygon set for the lazy-load path. |
| `package.json` | Dependency versions. |

---

## 4. The reservation (AIANNH) data pipeline — in detail

### 4a. Data origin
`tribalLands.generated.js` was generated from **Census TIGER/Line 2018 AIANNH
shapefiles** (`tl_2018_us_aiannh`, 491 features). The original generator script
(`scripts/build-tribal-geography.mjs`) is NOT in the repo — only its output is.
**This is why the generated file must travel with you; you cannot recreate it
from this brief alone.** If you must regenerate, the recipe is in §4e.

### 4b. Per-reservation record shape
`CENSUS_TRIBAL_LANDS` is an array of:

```js
{
  id: "aiannh-0010R",         // stable id, "aiannh-" + GEOID
  aiannhce: "0010",            // Census AIANNH census code
  geoid: "0010R",              // R = reservation, T = off-reservation trust land
  name: "Acoma Pueblo",        // full Census name
  shortName: "Acoma",          // display name
  fips: "35",                  // 2-digit STATE fips the land sits in
  category: "reservation",     // "reservation" | "off-reservation-trust" | ...
  pathD: "M279.8,379.4 L...Z",// SVG path, ALREADY projected into albers-10m space
  x: 282.25, y: 385.52,        // projected centroid (source-dot anchor)
  metadata: { areaSqMi: 184, source: "Census TIGER/Line 2018 AIANNH" }
}
```

**Critical:** `pathD`, `x`, `y` are already in the **same projected coordinate
space as `us-atlas` albers-10m**, so the polygons drop straight onto the map
SVG `viewBox` with no client-side projection. That alignment is the whole trick.

### 4c. The projection (must match exactly)
Everything shares one projection: `d3.geoAlbersUsa().scale(1300).translate([487.5, 305])`
(this is what `us-atlas` *-albers-10m.json bakes in). `countyMatch.ts` reconstructs
it to invert points:

```ts
const proj = geoAlbersUsa().scale(1300).translate([487.5, 305]);
// invert a projected (cx,cy) back to [lon,lat], then geoContains against counties
```

The map SVG `viewBox` in `MapWorkspace.astro` is `-60 5 1020 610` (tight-fit of
the albers-USA bbox with a small margin so AK inset + ME/WA edges stay visible).

### 4d. SSR build (in `MapWorkspace.astro` frontmatter)
1. Import `CENSUS_TRIBAL_LANDS`; filter to entries with `pathD && x!=null &&
   y!=null && fips`.
2. Build a **search index** (`type:'tribal'`) merged with states + counties:
   `{ type:'tribal', id, name: shortName||name, sub:`${category} · ${state}`,
   cx:x, cy:y, fips }`.
3. Build **tribalLookup** keyed by scene slug: for each slug in
   `TRIBAL_SCENE_KEYS`, find the first AIANNH whose `name` (case-insensitively)
   includes a candidate string; record `{name, cx, cy, fips}`. Then
   `Object.assign(tribalLookup, MANUAL_TRIBES)` so manual centroids win.
4. Enrich each lookup entry with `countyFips = findContainingCounty(cx,cy)` so a
   reservation scene can highlight **state → county → reservation** as a nested
   hierarchy.
5. Serialize to inline JSON `<script>` blocks the runtime reads by id:
   - `#heroStates`, `#heroCounties`, `#heroTribal`, `#heroSearch`.

### 4e. Regeneration recipe (only if you lack the generated file)
1. Download Census TIGER/Line 2018 AIANNH shapefile (`tl_2018_us_aiannh`).
2. Read features (e.g. `shapefile` npm pkg or `mapshaper`).
3. Project each ring with `geoAlbersUsa().scale(1300).translate([487.5,305])`,
   emit an SVG path (`d3.geoPath`), and compute the projected centroid.
4. Derive `fips` from GEOID/state; set `category` from the GEOID suffix
   (`R`=reservation, `T`=trust land). Write the array as
   `export const CENSUS_TRIBAL_LANDS = [...]`.

---

## 5. Runtime DOM contract (`hero.ts` ↔ markup)

The lazy-load + interaction wiring the runtime depends on. If you rebuild the
runtime, keep these ids/attrs:

- **Layer filters:** `button.wfilter[data-layer="states|counties|tribal"]`,
  role=tab. Switching to `tribal` triggers the AIANNH fetch if not loaded.
- **AIANNH overlay group:** `<g id="heroAiannhLayer" data-loaded="0">` — empty at
  SSR. On first map interaction (or idle), runtime `fetch('/data/aiannh.json')`,
  injects `<path class="hero-aiannh" data-id data-fips data-name>` per polygon,
  sets `data-loaded="1"`. **Event delegation** is on this group, so no re-wiring
  after injection.
- **Rendering order** (visual hierarchy state→county→reservation): states `<g>`,
  then `#heroCountyLayer`, then `#heroAiannhLayer`, then border meshes, then
  source/flow layers.
- **Source dot:** `#heroSource` (`cx/cy` set to the clicked geography's centroid).
- **Flow lines:** `#heroFlowLayer` (bezier source→top-impacted regions).
- **Search:** `#workspaceSearchInput` filters `#heroSearch` (Fuse.js); selecting a
  `tribal` entry fires the same runStudy a polygon click would.
- **Figures:** `#figDirect #figIndirect #figInduced #figTotal #figJobs`.
- **Chip/status:** `#workspaceRegion`, `#workspaceStudyId`, `#workspaceStatus`,
  `#workspaceStatusLabel`, `#workspaceActivity` (a11y live region).
- The runtime is imported at the bottom of `MapWorkspace.astro` via
  `<script>import '../scripts/hero.ts';</script>` (Astro bundles it).

---

## 6. Tier / pricing tie-in (for geography-related copy)

Every Lumecon tier covers full **reservation, county, state, and national**
scope. Per-platform geography labels live in `src/data/platforms.ts`
(`geographyScope`): Tribal is reservation-anchored ("Reservation, county, state,
and national"); Local is sub-state. Don't claim a geography a platform's
`geographyScope` doesn't list.

---

## 7. How to work on this (mobile session)

1. Read `MapWorkspace.astro` (frontmatter = data build) and `hero.ts` (runtime)
   together — they communicate only through the inline JSON `<script>` ids in §5.
2. To add/fix a reservation:
   - If it's in Census 2018: add/adjust a slug in `TRIBAL_SCENE_KEYS`
     (`tribalLookup.ts`).
   - If it's NOT in Census (newly recognized / new trust land): add a
     `MANUAL_TRIBES` entry with an albers-projected `{cx, cy, fips}`.
3. Verify visually: `npm run dev`, open `/map`, switch to the **Tribal lands**
   layer, search the nation, click it, confirm the source dot lands on the right
   centroid and the figures populate.
4. No `gh` CLI — use GitHub MCP tools for any PR/branch work. Chromium is
   pre-installed for Playwright (`/opt/pw-browsers/chromium`); don't run
   `playwright install`.

---

## Files in this archive
```
map-reservations-brief.md          ← this file
package.json
src/pages/map.astro
src/pages/data/aiannh.json.ts
src/components/MapWorkspace.astro
src/scripts/hero.ts
src/styles/hero.css
src/styles/map-page.css
src/data/tribalLookup.ts
src/data/countyMatch.ts
src/data/tribalLands.generated.js  ← 271 KB generated polygons (keep!)
```
